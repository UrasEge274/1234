from flask import Flask, render_template, redirect, request

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/Kedi")
def Kedi():
    return render_template("Kedi.html")

@app.route("/Köpek")
def Köpek():
    return render_template("Köpek.html")

@app.route("/Kuş")
def Kuş():
    return render_template("Kuş.html")

if __name__ == '__main__':
    app.run(debug = True)